GLYPHISH PRO v2
Created by Joseph Wain
WWW: http://glyphish.com or http://penandthink.com
Twitter: @glyphish or @jpwain

----------

Thanks for supporting Glyphish!

LICENSE:
You're free to use these icons for commercial and non-commercial purposes, for yourself, your company and your clients, and to edit, remix and otherwise modify them without attribution, but not to sell or redistribute the icons themselves as such. Additionally, please do not use them in a way that encourages downstream distribution without attribution -- such as templates or theme kits, where the person using the theme or template might not know where the icons came from and thus wouldn't provide attribution.

ATTRIBUTION:
None required for use by you, your company, your clients. But if you'd like to spread the word by linking to Glyphish from your website, blogpost, Twitter or wherever, your kind words are much appreciated.

QUESTIONS, COMMENTS:
Contact me via glyphish.com.